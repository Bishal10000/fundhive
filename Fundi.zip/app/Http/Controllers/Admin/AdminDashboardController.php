<?php

namespace App\Http\Controllers\Admin;

/**
 * Backwards-compatible shim. The real implementation lives in `DashboardController`.
 */
class AdminDashboardController extends DashboardController
{
    // intentionally empty - extends main DashboardController
}
