@extends('layouts.admin')

@section('title', 'Flagged Campaigns')

@section('content')
<section class="content">
    <div class="container-fluid">
        <h1 class="mb-3">Flagged Campaigns</h1>

        @if (session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <div class="alert alert-info">
            Campaigns shown here were flagged by the fraud detection service. Approving will restore visibility; rejecting will suspend the campaign.
        </div>

        <div class="card">
            <div class="card-body table-responsive p-0">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Owner</th>
                            <th>Fraud Score</th>
                            <th>Status</th>
                            <th class="text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($campaigns as $campaign)
                            <tr>
                                <td class="font-weight-bold">{{ $campaign->title }}</td>
                                <td>{{ optional($campaign->user)->name ?? 'Unknown' }}</td>
                                <td><span class="badge badge-danger">{{ $campaign->fraud_score }}</span></td>
                                <td>
                                    <span class="badge badge-{{ $campaign->status === 'suspended' ? 'danger' : 'warning' }}">
                                        {{ ucfirst($campaign->status) }}
                                    </span>
                                </td>
                                <td class="text-right">
                                    <form method="POST" action="{{ route('admin.fraud.approve', $campaign) }}" class="d-inline">
                                        @csrf
                                        <button class="btn btn-sm btn-outline-success">Approve</button>
                                    </form>

                                    <form method="POST" action="{{ route('admin.fraud.reject', $campaign) }}" class="d-inline ml-1">
                                        @csrf
                                        <button class="btn btn-sm btn-outline-danger">Reject</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted p-3">No flagged campaigns right now.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                {{ $campaigns->links() }}
            </div>
        </div>
    </div>
</section>
@endsection
