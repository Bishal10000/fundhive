@extends('layouts.admin')

@section('title', 'Admin Dashboard')

@section('content')
<section class="content">
    <div class="container-fluid">
        <h1 class="mb-4">Admin Dashboard</h1>

        @if (session('status'))
            <div class="alert alert-success">{{ session('status') }}</div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <div class="row">
            <div class="col-lg-3 col-6">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3>{{ $stats['total_users'] }}</h3>
                        <p>Total Users</p>
                    </div>
                    <div class="icon"><i class="fas fa-users"></i></div>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3>{{ $stats['total_campaigns'] }}</h3>
                        <p>Total Campaigns</p>
                    </div>
                    <div class="icon"><i class="fas fa-bullhorn"></i></div>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box bg-warning">
                    <div class="inner">
                        <h3>{{ $stats['active_campaigns'] }}</h3>
                        <p>Active Campaigns</p>
                    </div>
                    <div class="icon"><i class="fas fa-eye"></i></div>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3>{{ $stats['flagged_campaigns'] }}</h3>
                        <p>Flagged Campaigns</p>
                    </div>
                    <div class="icon"><i class="fas fa-shield-alt"></i></div>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box bg-primary">
                    <div class="inner">
                        <h3>{{ $stats['total_donations'] }}</h3>
                        <p>Completed Donations</p>
                    </div>
                    <div class="icon"><i class="fas fa-hand-holding-heart"></i></div>
                </div>
            </div>

            <div class="col-lg-3 col-6">
                <div class="small-box bg-teal">
                    <div class="inner">
                        <h3>${{ number_format($stats['total_raised'], 2) }}</h3>
                        <p>Total Raised</p>
                    </div>
                    <div class="icon"><i class="fas fa-dollar-sign"></i></div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0">Recent Campaigns</h3>
                        <a href="{{ route('admin.campaigns') }}" class="btn btn-sm btn-outline-primary">Manage</a>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Owner</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($recentCampaigns as $campaign)
                                    <tr>
                                        <td>{{ $campaign->title }}</td>
                                        <td>{{ optional($campaign->user)->name ?? 'Unknown' }}</td>
                                        <td>
                                            <span class="badge badge-{{ $campaign->status === 'active' ? 'success' : ($campaign->status === 'suspended' ? 'danger' : 'secondary') }}">
                                                {{ ucfirst($campaign->status) }}
                                            </span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="3" class="text-center text-muted p-3">No campaigns yet.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0">Flagged Campaigns</h3>
                        <a href="{{ route('admin.fraud') }}" class="btn btn-sm btn-outline-danger">Review All</a>
                    </div>
                    <div class="card-body p-0">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Owner</th>
                                    <th>Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($flaggedCampaigns as $campaign)
                                    <tr>
                                        <td>{{ $campaign->title }}</td>
                                        <td>{{ optional($campaign->user)->name ?? 'Unknown' }}</td>
                                        <td>
                                            <span class="badge badge-danger">{{ $campaign->fraud_score }}</span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="3" class="text-center text-muted p-3">No flagged campaigns.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title mb-0">Recent Fraud Logs</h3>
            </div>
            <div class="card-body p-0">
                <table class="table table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Campaign</th>
                            <th>User</th>
                            <th>Message</th>
                            <th>When</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($fraudLogs as $log)
                            <tr>
                                <td>{{ optional($log->campaign)->title ?? 'N/A' }}</td>
                                <td>{{ optional($log->user)->name ?? 'System' }}</td>
                                <td>{{ $log->admin_notes ?? 'Flagged for review' }}</td>
                                <td>{{ $log->created_at->diffForHumans() }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted p-3">No fraud logs yet.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection
